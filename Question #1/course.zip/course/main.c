/**
 * @file main.c
 * @author Unknown [Documented by: Ishpreet Nagi (nagii)]
 * @brief The purpose of this code is to create courses and then fill them with students. My purpose as the documenter, is the document this code using Doxygen, creating comments explaining its inner-workings so that anyone who reads it can turly understand it.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The purpose of the main function is to call upon the other helper functions located the files of 'student.c' and 'course.c', to create a course, populate it with students, and then print those courses upon the screen for the user to see. 
 * 
 * @return It does not return anything. 
 */
int main()
{
  srand((unsigned) time(NULL));
  /*
  We defining a new dynamic array called "MATH101" of the typedef 'Course' and 
  using calloc are setting the size of the dynamic array to 1, this the course 
  we are creating which we will be filling up with students.
  */
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  /*
  The for-loop calls the function 'enroll_student' located in the file 'course.c', 
  sending it the dynamic array 'MATH101' and the output of the function 
  'generate_random_student' located in the file 'student.c' to which it sending the 
  int value of 8. Overall this process is repeated 20 times to fill the dynamic 
  array of 'MATH101' up with 20 ranomly generated students which are output by the 
  'generate_random_student' function.
  */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  /*
  We are defining a new variable of the typedef 'Student" and calling it 'student' 
  as way to use that to represent the top student within the course called 'MATH101', 
  which we do by making the array be equal to output of the function 'top_student'
  */
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;

  /*
  We are generating a new dynamic array called 'passing_students' of the typedef 'student' 
  and filling the memory locating it is pointing to with the return output of the function 
  'passing' located in the file 'course.c'. Sending the 'passing' function the dyanmic array 
  of MATH101 and a pointer pointing to the memory address of the int variable called 
  'total_passing', so that we can use the 'passing_students' dyanmic array to showcase the 
  students within the dynamic array 'MATH101' that are passing the course. 
  */
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");

  /*
  The for-loop calls the function 'print_student' 20 times, sending it a pointer pointing 
  to the memory location of the pointer 'passing_students' to print the names of the students 
  that are passing the course 'MATH101' and are stored in the dynamic array 'MATH101'
  */
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}