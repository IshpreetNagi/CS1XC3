/**
 * @file student.c
 * @author Unknown [Documented by: Ishpreet Nagi (nagii)]
 * @brief This file contains all functions associated with manipulating a student's individual infromation, or just any actions associated with an individual student's  infromation.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This void function takes the student infromation in the form of a dynamic array of the typedef 'Student' as well as the student's corresponding grade, adds that grade into the taken in dynamic array.
 * 
 * @param student A pointer of the typdef 'Student', pointing to the variable/dynamic array where the information of the student in question is held. 
 * @param grade The double value representing the student's grade that must be added to the given dynamic array
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;

  /*
  If a student only has one grade attached to them, then the size of 
  the dynamic array called 'grades' of the double type within the 
  'Student' typedef variable 'student' is set to be one, as they only 
  have a single grade and so the dynamic array only needs to hold one value
  */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {

    /*
    The size of the dyanmic array called 'grades' of the double type within 
    the 'student' variable of the typedef 'Student' is reset to be the number 
    of grades associated to the student to ensure that the dynamic array of 
    'grades' can hold the required amounts of grades for that student. The size 
    of the dynamic array is changed using realloc.
    */
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This double function returns the averge percentage of a student.
 * 
 * @param student A pointer of the typedef 'Student', pointing to the variable/dynamic array where the information of the student in question is held.
 * @return double variable (The average grade of the student provided)
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;

  /*
  The for-loop repeats according to the number of grades associated with a 
  student, and as it repeats, it adds every grade of the student to the 'total' 
  double variable.
  */
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief This void function prints out the information regarding the student which it is given. So really just printing to screen all the contents of the pointer variable of the typedef 'Student' that is provided.
 * 
 * @param student A pointer of the typedef 'Student', pointing to the variable/dynamic array where the information of the student in question is held.
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  /*
  The for-loop repeats the number of times corresponding to the number of grades 
  asscoiated with the student, so the int variable 'num_grades', printing out each 
  value, which is essentially each grade of the student stored within the dynamic array 
  'grades' of double type within the given 'Student' typedef variable referred to in 
  the function as 'student'
  */
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This 'Student' typedef function actually generates the random infromation about a student, fills it in a 'Student' typedef variable and returns it. Essentially, creating the students that will compose the courses. 
 * 
 * @param grades An int value holding the number of grades a student is to have.
 * @return Student* (The 'Student' typedef variable holding all the information regarding the student)
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  /*
  Creating a 'Student' typedef dynamic array and setting it's size to be equal to 1
  */
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /*
  The for-loop creates the id character string of the student, it repeats 10 times, 
  randomly generating a value between 0 - 9 and then converting that to a ASCII 
  character, and then storing that into the id character array (string) within the 
  'Student' typedef. Thus creating the id for the student in question.
  */
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /*
  The for-loop repeats the number of times corresponding to the amount of grades the 
  student is to have, and essentially randomly generates a double value between 0 - 75, 
  and then storing that into the 'grades' dynamic array within the 'Student' typedef 
  for the student that is being created currently.
  */
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}