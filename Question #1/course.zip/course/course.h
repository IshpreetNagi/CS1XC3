/**
 * @file course.h
 * @author Unknown [Documented by: Ishpreet Nagi (nagii)]
 * @brief The purpose of this file is to create the 'Course' typedef and define the functions with the 'course.c' file so they can be called from other files.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Constructing the typedef '_course' using a struct, and then giving it the name 'Course', which it can be reffered to as throughout the code to make it easier to store infromation under the term of a course in more organized manner. 
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Defining all the functions located within the 'course.c' file to allow for them to be called from other files.
 * @param student A pointer of the typdef 'Student' pointing to the variable/dynamic array holding all of a student's information 
 * @param course A pointer of the typdef 'Course' pointing to the variable/dynamic array holding information about the overall course
 * @param total_passing A pointer of the type int pointing to the variable/dynamic array holding the total number of students passing the course
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


