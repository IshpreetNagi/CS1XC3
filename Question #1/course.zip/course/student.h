/**
 * @file course.h
 * @author Unknown [Documented by: Ishpreet Nagi (nagii)]
 * @brief The purpose of this file is to create the 'Student' typedef and define the functions with the 'student.c' file so they can be called from other files.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Constructing the typedef '_student' using a struct, and then giving it the name 'Student', which it can be reffered to as throughout the code to make it easier to store infromation under the term of a student in more organized manner. 
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Defining all the functions located within the 'student.c' file to allow for them to be called from other files.
 * 
 * @param student A pointer of the typdef 'Student' poiting to the variable/dynamic array holding all of a student's information 
 * @param grade A double variable holding the grade of the student.
 * @param grades A int value holding the total number of grades asscoaited to a student.
 */
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
