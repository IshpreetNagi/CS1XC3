/**
 * @file student.c
 * @author Unknown [Documented by: Ishpreet Nagi (nagii)]
 * @brief This file contains all functions associated with manipulating the course's overall infromation, or just any actions associated with the overall course's infromation.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief This void function adds the given 'Student' typedef variable to the given 'Course" type def variable, essentially enrolling a student into the course.
 * 
 * @param course A pointer of the typdef 'Course' pointing to the variable/dynamic array holding information about the overall course 
 * @param student A pointer of the typdef 'Student' pointing to the variable/dynamic array holding all of a student's information 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    /*
    Sets the size of the 'students' dynamic array within the 'Course' typedef variable 
    'course' to be equal to 1, as in this if statement, it has been established that 
    there is only one student in the course, hence the 'students' dynamic array only 
    needs to hold one student, so its size can be equal to 1. 
    */
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    /*
    Resets the size of the 'students' dynamic array within the 'Course' typedef variable 
    'course' to be equal to the total number of students enrolled in that course, so that 
    the 'student' dynamic array has the needed space. This storage is set using realloc.
    */
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This void function prints out the information regarding the course which it is given. So really just printing to screen all the contents of the pointer variable of the typedef 'Course' that is provided.
 * 
 * @param course A pointer of the typdef 'Course' pointing to the variable/dynamic array holding information about the overall course
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

    /*
    The for-loop repeats the number of times corresponding to the number of students 
    asscoiated with the given course, so the int variable 'total_students', printing 
    out each value, which is essentially each student enrolled in the course stored 
    within the dynamic array 'students' of the 'Student' typedef within the given 
    'Course' typedef variable reffered to in the function as 'course'
    */
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This 'Student' typedef function returns the top students within the provided course, so the student with the highest average
 * 
 * @param course A pointer of the typdef 'Course' pointing to the variable/dynamic array holding information about the overall course
 * @return Student* (The 'Student' typedef variable that has the highest average in the provided course)
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);

  Student *student = &course->students[0];
  
  /*
  The for-loop repeats a number of times corressponding to the total number of students 
  within the course, and the purpose of the for-loop is to go through the students within 
  the course, comparing their grade averages and finding the student with the highest 
  average so they can be called the top student.
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function finds the number of students within the provided course whose averages are higher than 50%, thus they are passing the course
 * 
 * @param course A pointer of the typdef 'Course' pointing to the variable/dynamic array holding information about the overall course
 * @param total_passing A pointer of the type int pointing to the variable/dynamic array holding the total number of students passing the course
 * @return Student* (The dyanmic array of the typedef 'Student" that are passing the course)
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;

  Student *passing = NULL;
  
  /*
  The for-loop repets itself a total number of times that coressponds to the total 
  number of students within the provided courses. And it essentially sees if the 
  student has a grade average higher than 50%, and it increases a counter by 1 
  when a student with a grade average than 50% is found.
  */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /*
  Sets the size of the previosuly established dynamic array of the typedef 'Student' 
  called 'passing' to the number of students that had been found to have a grade 
  average higher than 50% in the for-loop.
  */
  passing = calloc(count, sizeof(Student));

  int j = 0;

  /*
  The for-loop repets itself a total number of times that coressponds to the total number 
  of students within the provided courses. And it essentially sees if the student has a 
  grade average higher than 50%, but this time, adding those found students to the 
  'passing' dynamic array. 
  */
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}