var searchData=
[
  ['top_5fstudent_0',['top_student',['../course_8h.html#ac1d82150824c7ecd43bab36fb83cd779',1,'course.c']]]
];
